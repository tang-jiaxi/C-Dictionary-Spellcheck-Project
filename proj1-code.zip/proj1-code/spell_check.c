#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h> //is this allowed

#include "dictionary.h"

#define MAX_CMD_LEN 128

// A helper function to spell check a specific file
// 'file_name': Name of the file to spell check
// 'dict': A dictionary containing correct words
int spell_check_file(const char *file_name, const dictionary_t *dict) {
    // TODO Not yet implemented
    FILE *file_handle = fopen(file_name, "r");
    if (file_handle == NULL) {
        printf("Spell check failed\n");
        return 0;
    }
    char words[MAX_WORD_LEN];
    char line[MAX_WORD_LEN * 10];
    int found = 0;
    int line_index = 0;
    while (fgets(line, MAX_WORD_LEN * 10, file_handle) != NULL) {
        //Restart line index for each new line
        line_index = 0;

        //Scan each word in the line one by one
        while (sscanf(&line[line_index], "%s", words) == 1) {
            //Check if word exists in dictionary
            found = dict_find(dict, words); //how come I dont hv to append \n to words so it matches the words in dict
            if (found == 0) {
                printf("%s[X]", words);
            }
            else if (found == 1) {
                printf("%s", words);
            }
            //Update line index. strlen() doesnt count spaces, NUL or \n
            //scanf helps increment line_index & it stops at the next char
            //aft the word, which will def be either a space, NUL or \n,
            //so no need to +1 to index
            line_index += strlen(words);
            // Pointer arithmetic to find the character right after NUL char
            if (line[line_index] == ' ') {
                printf(" ");
            } 
            if (line[line_index] == '\n') {
                printf("\n");
            } 
            line_index ++;
        }
    }
    fclose(file_handle);
    return 1;
}

/*
 * This is in general *very* similar to the list_main file seen in lab
 */
int main(int argc, char **argv) {
    dictionary_t *dict = create_dictionary();
    char cmd[MAX_CMD_LEN];

    if (argc >= 2) {
        dict_free(dict);
        dict = read_dict_from_text_file(argv[1]);
        if (dict == NULL) {
            return 0;
        } 
        if (argc == 3) {
            spell_check_file(argv[2], dict);
            dict_free(dict);
            return 0;
        }

    }

    printf("CSCI 2021 Spell Check System\n");
    printf("Commands:\n");
    printf("  add <word>:              adds a new word to dictionary\n");
    printf("  lookup <word>:           searches for a word\n");
    printf("  print:                   shows all words currently in the dictionary\n");
    printf("  load <file_name>:        reads in dictionary from a file\n");
    printf("  save <file_name>:        writes dictionary to a file\n");
    printf("  check <file_name>: spell checks the specified file\n");
    printf("  exit:                    exits the program\n");

    //this gives u an infinite loop
    while (1) {
        printf("spell_check> ");

        if (scanf("%s", cmd) == EOF) {
            printf("\n");
            break;
        }

        else if (strcmp("exit", cmd) == 0) {
            break;
        }

        else if (strcmp("add", cmd) == 0) {
            char word[128];
            scanf("%s", word); //read a string
            dict_insert(dict, word);
        }

       else if (strcmp("lookup", cmd) == 0) {
            char word[128];
            scanf("%s", word); //read a string
            int found = dict_find(dict, word);
            if (found == 0) {
                printf("'%s' not found\n", word);
            }
            else {
                printf("'%s' present in dictionary\n", word);
            }
        }

        else if (strcmp("print", cmd) == 0) {
            dict_print(dict);
        }

        else if (strcmp("load", cmd) == 0) {
            char file_name[128];
            scanf("%s", file_name);  
            dict_free(dict);
            //Reassign cleared dict pointer to new dict
            dict = read_dict_from_text_file(file_name);
        }

        // TODO Add cases for the other commands
        // Read in the command and any additional Sarguments (where needed)

        else if(strcmp("save", cmd) == 0) {
            char file_name[128];
            scanf("%s", file_name);
            write_dict_to_text_file(dict, file_name);
        }

        else if(strcmp("check", cmd) == 0) {
            char file_name[128];
            scanf("%s", file_name);
            spell_check_file(file_name, dict);
        }
        else {
            printf("Unknown command %s\n", cmd);
        }
    }
    dict_free(dict);
    return 0;
}