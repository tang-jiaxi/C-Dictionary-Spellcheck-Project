#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dictionary.h"

dictionary_t *create_dictionary() {
    dictionary_t *dict = malloc(sizeof(dictionary_t));
    if (dict == NULL) {
        return NULL;
    }
    dict->root = NULL;
    dict->size = 0;
    return dict;
}

node_t *create_node(node_t *node, const char *word) {
    strcpy(node -> word, word);
    node -> left = NULL;
    node -> right = NULL;
    return node;
}

int dict_insert_helper(node_t *node, const char *word, dictionary_t *dict) {
    //Recurse until empty spot is found
    if (node != NULL) {
        //Move right
        if (strcmp(word, node -> word) > 0) {
            if (node -> right == NULL) {
                node -> right = malloc(sizeof(node_t));
                //malloc() error check:
                if (node -> right == NULL) {
                    return -1;
                }
                create_node(node -> right, word);
                dict -> size++;
                // free(node -> right);
                return 0;
            }
            //Next child is not empty, continue recursion
            dict_insert_helper(node -> right, word, dict);
        }
        //Move right
        else if (strcmp(word, node -> word) < 0) {
            if (node -> left == NULL) {
                node -> left = malloc(sizeof(node_t));
                //malloc() error check:
                if (node -> left == NULL) {
                    return -1;
                }
                create_node(node -> left, word);
                dict -> size++;
                // free(node -> left);
                return 0;
            }
            //Next child is not empty, continue recursion
            dict_insert_helper(node -> left, word, dict);
        }
    }
    //Word already exists
    return -1;
}

int dict_insert(dictionary_t *dict, const char *word) {

    //Save current size locally
    int current_size = dict -> size;

    //Check word not NULL
    if (word == NULL) {
        return -1;
    }

    //If dict empty, make new node at root
    if (dict -> root == NULL) {
        dict -> root = malloc(sizeof(node_t));
        //Check if malloc() worked
        if (dict -> root == NULL) {
            return -1;
        } 
        //make a new node at root
        create_node(dict -> root, word);
        dict -> size++;
        return 0;
    }
    //If dict not empty, find where to add newNode
    else {
        dict_insert_helper(dict -> root, word, dict);
        if (dict -> size > current_size) {
            return -1;
        }
        else {
            return 0;
        }
    }
}

int dict_find_helper(node_t *node, const char *query) {
    if (node != NULL) {
        if (strcmp(query, node -> word) > 0) {
            return dict_find_helper(node -> right, query);
        }
        else if (strcmp(query, node -> word) < 0) {
            return dict_find_helper(node -> left, query);
        }
        else if (strcmp(query, node -> word) == 0) {
            return 1;
        }
    }
    return 0;
}

int dict_find(const dictionary_t *dict, const char *query) {
    node_t *seek; //when do i use malloc....
    seek = dict -> root;

    if (dict -> size == 0){
        return 0;
    }
    else {
        return dict_find_helper(seek, query);
    }
}

void inorder(node_t *node)
{
    if (node != NULL) {
        inorder(node -> left);    
        printf("%s\n", node -> word);
        inorder(node -> right);
    }
    return;
}

void dict_print(const dictionary_t *dict) {
    if (dict -> size == 0){
        return;
    }
    else {
        inorder(dict -> root);
    }
    return;
}

dictionary_t *read_dict_from_text_file(const char *file_name) {
    //Open file
    FILE *file_handle = fopen(file_name, "r");

    //Print fail msg
    if (file_handle == NULL) {
        printf("Failed to read dictionary from text file\n");
        return NULL;
    }
    else {
        //Print success msg
        printf("Dictionary successfully read from text file\n");
        dictionary_t *read_dict = create_dictionary();

        //If theres nothing to print, close file
        if (read_dict == NULL) { //why do i get seg fault when i do read_dict -> root, assuming there is a dict?
            fclose(file_handle);
            return NULL;
        }

        //Insert each word
        char word[MAX_WORD_LEN];
        while (fscanf(file_handle, "%s ", word) == 1) {
            dict_insert(read_dict, word);
        }
        fclose(file_handle);
        return read_dict;
    }
}

void inorder_write_dict (const node_t *node, FILE *file_handle) {
    if (node != NULL) {
        fprintf (file_handle, "%s\n", node -> word);
        inorder_write_dict(node -> left, file_handle);    
        inorder_write_dict(node -> right, file_handle);
    }
    return;
}

int write_dict_to_text_file(const dictionary_t *dict, const char *file_name) {
    FILE *file_handle = fopen(file_name, "w");

    //If file cant open, print error msg
    if (file_handle == NULL) {
        printf("Failed to write dictionary to text file\n");
        return -1;
    }
    else {
        printf("Dictionary successfully written to text file\n");
        inorder_write_dict(dict -> root, file_handle);
        fclose(file_handle);
        return 0;
    }
}

void free_entire_tree(node_t *node) {
    if (node == NULL) {
        return;
    }
    free_entire_tree(node->left);
    free_entire_tree(node->right);
    free(node);
}
void dict_free(dictionary_t *dict) {
    if (dict == NULL) {
        return;
    }
    free_entire_tree(dict->root);
    free(dict);
}





        //if i dont want a helper, what while condition am i supposed to use

        // dict_print_helper(seek); 
        // while (print_seek -> right != NULL || print_seek -> left != NULL) {
        //     print_seek = print_seek -> left;
        //     printf("%s\n", print_seek -> word);
        //     printf("test1");
        //     print_seek = print_seek -> right;
        // }
        // printf("test2");

    // free(print_seek -> left);
    // free(print_seek -> right);
    // free(print_seek);  //why do i need to free print_seek?

        // while (seek -> right != NULL && seek -> left != NULL) {
    //     if (strcmp(query, seek -> word) > 0) {
    //         seek = seek -> right;
    //     }
    //     else if (strcmp(query, seek -> word) < 0) {
    //         seek = seek -> left;
    //     }
    //     else if (strcmp(query, seek -> word) == 0) {
    //         free(seek -> left);
    //         free(seek -> right);
    //         free(seek);
    //         return 1;
    //     }
    // }
    // free(seek -> left);
    // free(seek -> right);
    // free(seek);
    // // printf("%s not found", query);
    // return 0;

            // while (seek -> left != NULL || seek -> right != NULL) {
        //     if (strcmp(word, seek -> word) > 0) {
        //         seek = seek -> right;
        //     }
        //     else if (strcmp(word, seek -> word) < 0) {
        //         seek = seek -> left;
        //     }
        //     else if (strcmp(word, seek -> word) == 0) {
        //         return -1;
        //     }
        // }
        // if (strcmp(word, seek -> word) > 0) {
        //         seek -> right = newNode;
        // }
        // else if (strcmp(word, seek -> word) < 0) {
        //         seek -> left = newNode;
        // }
    // free(newNode -> left);
    // free(newNode -> right);

    // node_t *create_node(node_t *node, const char *word) {
//     size_t word_len;
//     word_len = strlen(word);
//     if  (node == NULL) {
//         strcpy(node -> word, word);
//         node -> word[word_len] = '\0';
//         node -> left = NULL;
//         node -> right = NULL; 
//         return node; 
//     }
    
//     while (node != NULL) {
//         if (strcmp(word, node -> word) > 0) {
//             create_node (node -> right, word);
//         }
//         else if (strcmp(word, node -> word) < 0) {
//             create_node (node -> left, word);
//         }
//         else if (strcmp(word, node -> word) == 0) {
//             return node;
//         }
//     }
//     strcpy(node -> word, word);
//     node -> word[word_len] = '\0';
//     node -> left = NULL;
//     node -> right = NULL; 
//     return node;
// }

// node_t *create_node(node_t *node, const char *word) {
//     int word_len;
//     word_len = strlen(word);
//     while (node != NULL) {
//         if (strcmp(word, node -> word) > 0) {
//             create_node (node -> right, word);
//         }
//         else if (strcmp(word, node -> word) < 0) {
//             create_node (node -> left, word);
//         }
//         else if (strcmp(word, node -> word) == 0) {
//             return node;
//         }
//     }
// }

// node_t *dict_insert_node(dictionary_t *dict, const char *word) 
// {
//     if (dict -> root == NULL)
//     {
//         return create_node(word);
//     }
//     if (strcmp(word, dict -> root -> word) > 0) {
//         dict -> root = dict_insert_node(dict -> root -> right, word);
//     }
//     else if (strcmp(word, dict -> root -> word) < 0) {
//         dict -> root = dict_insert_node(dict -> root -> left, word);
//     }
//     return dict -> root;
// }

// int dict_insert(dictionary_t *dict, const char *word)
// {
//    dict -> root = dict_insert_node(dict -> root, word);
//    if (dict_insert_node(dict -> root, word) == NULL) {
//     return -1;
//    }
//    else {
//     return 0;
//    }
// }